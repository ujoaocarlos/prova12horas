<?php

    if(isset($_POST['submit']))
    {
        // print_r('Nome: ' . $_POST['nome']);
        // print_r('<br>');
        // print_r('Email: ' . $_POST['email']);
        // print_r('<br>');
        // print_r('Telefone: ' . $_POST['telefone']);
        // print_r('<br>');
        // print_r('Sexo: ' . $_POST['genero']);
        // print_r('<br>');
        // print_r('Data de nascimento: ' . $_POST['data_nascimento']);
        // print_r('<br>');
        // print_r('Cidade: ' . $_POST['cidade']);
        // print_r('<br>');
        // print_r('Estado: ' . $_POST['estado']);
        // print_r('<br>');
        // print_r('Endereço: ' . $_POST['endereco']);

        include_once('config.php');

        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $senha = $_POST['senha'];
        $ra = $_POST['ra'];
        $sexo = $_POST['genero'];
        $data_nasc = $_POST['data_nascimento'];
        $cidade = $_POST['cidade'];
        $estado = $_POST['estado'];
        $endereco = $_POST['endereco'];

        $result = mysqli_query($conexao, "INSERT INTO usuarios(nome,senha,ra,email,sexo,data_nasc,cidade,estado,endereco) 
        VALUES ('$nome','$senha','$ra','$email','$sexo','$data_nasc','$cidade','$estado','$endereco')");

        header('Location: login.php');
    }

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Registro - Aluno</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * {
  box-sizing: border-box;
}

body {
  font-family: 'Poppins', sans-serif;
  background: linear-gradient(to right, #f0faff, #ffffff);
  margin: 0;
  padding: 40px 0; /* margem vertical */
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: calc(100vh - 80px); /* diminui para considerar o padding vertical */
}

.container {
  background: #ffffff;
  padding: 30px;
  border-radius: 15px;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
  max-width: 500px;
  width: 100%;
  animation: fadeIn 0.7s ease-in-out;
  margin: 40px 0; /* margem acima e abaixo */
}

.container > a {
  display: inline-block;
  margin-bottom: 20px;
  color: #0074D9;
  font-weight: 600;
  text-decoration: none;
  padding: 8px 16px;
  border: 2px solid #0074D9;
  border-radius: 8px;
  transition: background-color 0.3s, color 0.3s;
  cursor: pointer;
}

.container > a:hover {
  background-color: #0074D9;
  color: white;
}

.container img {
  display: block;
  margin: 0 auto 20px auto; /* centraliza horizontalmente e adiciona margem abaixo */
  height: 50px;     
  width: auto;   
}
h2 {
  text-align: center;
  margin-bottom: 20px;
  color: #003347;
}

.form-group {
  margin-bottom: 20px; /* aumentei para mais espaço */
  animation: slideUp 0.5s ease forwards;
}

.form-group label {
  display: block;
  font-weight: 500;
  margin-bottom: 8px; /* espaço entre label e input */
  color: #003347;
}

.form-group label.required::after {
  content: " *";
  color: red;
}

.form-group input[type="text"],
.form-group input[type="email"],
.form-group input[type="password"],
.form-group input[type="date"] {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 14px;
  transition: all 0.3s ease;
  display: block;
}

.form-group input:focus {
  border-color: #0db6ff;
  outline: none;
  box-shadow: 0 0 5px rgba(13, 182, 255, 0.4);
}

.radio-group {
  display: flex;
  gap: 20px; /* mais espaçamento */
  margin-top: 8px; /* para dar distância do label */
  align-items: center; /* para alinhar verticalmente */
}

.radio-group input[type="radio"] {
  cursor: pointer;
}

.radio-group label {
  font-weight: normal;
  cursor: pointer;
  user-select: none;
}

button[type="submit"] {
  background-color: #0074D9;
  color: white;
  border: none;
  padding: 12px;
  width: 100%;
  border-radius: 10px;
  font-size: 16px;
  cursor: pointer;
  transition: background 0.3s ease;
}

button[type="submit"]:hover {
  background-color: #009fd4;
}

a {
  color: #0db6ff;
  text-decoration: none;
  display: inline-block;
  margin-bottom: 15px;
}

/* Animações */
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

@keyframes slideUp {
  from { opacity: 0; transform: translateY(30px); }
  to { opacity: 1; transform: translateY(0); }
}

@media (max-width: 600px) {
  .container {
    padding: 20px;
  }
}
</style>
</head>
<body>
  <div class="container">
    <a href="home.php">← Voltar</a>
     <img src="assets/img/LOGO2.png" alt="Logo">
    <h2>Registre-se</h2>
    <form action="formulario.php" method="POST">
      <div class="form-group">
        <label for="nome" class="required">Nome completo</label>
        <input type="text" name="nome" id="nome" required>
      </div>

      <div class="form-group">
        <label for="senha" class="required">Senha</label>
        <input type="password" name="senha" id="senha" required>
      </div>

      <div class="form-group">
        <label for="email" class="required">Email</label>
        <input type="email" name="email" id="email" required>
      </div>

      <div class="form-group">
        <label for="ra" class="required">RA</label>
        <input type="text" name="ra" id="ra" required>
      </div>

      <div class="form-group">
        <label class="required">Sexo</label>
        <div class="radio-group">
          <input type="radio" id="feminino" name="genero" value="feminino" required>
          <label for="feminino">Feminino</label>
          <input type="radio" id="masculino" name="genero" value="masculino">
          <label for="masculino">Masculino</label>
          <input type="radio" id="outro" name="genero" value="outro">
          <label for="outro">Outro</label>
        </div>
      </div>

      <div class="form-group">
        <label for="data_nascimento" class="required">Data de Nascimento</label>
        <input type="date" name="data_nascimento" id="data_nascimento" required>
      </div>

      <div class="form-group">
        <label for="cidade" class="required">Cidade</label>
        <input type="text" name="cidade" id="cidade" required>
      </div>

      <div class="form-group">
        <label for="estado" class="required">Estado</label>
        <input type="text" name="estado" id="estado" required>
      </div>

      <div class="form-group">
        <label for="endereco" class="required">Endereço</label>
        <input type="text" name="endereco" id="endereco" required>
      </div>

      <button type="submit" name="submit">Enviar</button>
    </form>
  </div>

  <script>
    // Animação de foco com leve delay
    document.querySelectorAll("input").forEach((input, i) => {
      input.style.opacity = 0;
      setTimeout(() => {
        input.style.transition = 'opacity 0.5s ease';
        input.style.opacity = 1;
      }, 200 + (i * 100));
    });

    // Suavidade ao enviar o formulário
    const form = document.querySelector("form");
    form.addEventListener("submit", () => {
      form.style.opacity = 0.7;
    });
  </script>
</body>
</html>

