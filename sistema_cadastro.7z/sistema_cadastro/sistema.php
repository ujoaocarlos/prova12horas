<?php
session_start();
include_once('config.php');

if ((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true)) {
    unset($_SESSION['email']);
    unset($_SESSION['senha']);
    header('Location: login.php');
}

$logado = $_SESSION['email'];
$data = !empty($_GET['search']) ? $_GET['search'] : "";
$sql = !empty($data)
    ? "SELECT * FROM usuarios WHERE id LIKE '%$data%' OR nome LIKE '%$data%' OR telefone LIKE '%$data%' OR email LIKE '%$data%' ORDER BY id DESC"
    : "SELECT * FROM usuarios ORDER BY id DESC";
$result = $conexao->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Sistema Acadêmico</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * {
            transition: all 0.3s ease-in-out;
        }

        body {
            background: #f8fafc;
            color: #333;
            font-family: 'Poppins', sans-serif;
        }

        .navbar {
            background-color: #0074D9;
            padding: 1rem;
        }

        .navbar-brand {
            font-weight: 600;
            font-size: 1.5rem;
            color: white;
        }

        .btn-danger {
            background-color: #dc3545;
            border: none;
        }

        .box-search {
            margin: 2rem auto;
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            align-items: center;
            max-width: 600px;
            width: 90%;
        }

        .btn-search {
            background-color: #0074D9;
            border: none;
            padding: 0.5rem 1rem;
            font-weight: 600;
            color: white;
            border-radius: 5px;
        }

        .btn-search:hover {
            background-color: #009acd;
        }

        .container {
            background: white;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
            max-width: 1200px;
            margin: 0 auto 3rem auto;
        }

        .navbar img{
      display: block;
      margin-left: 1.5rem;
      height: 50px;     
      width: auto;  
    }       

        h2 {
            font-weight: 600;
            margin-bottom: 1rem;
        }

        .section-title {
            margin-top: 2rem;
            font-size: 1.25rem;
            font-weight: 600;
            color: #444;
            border-bottom: 2px solid #00BFFF;
            display: inline-block;
            padding-bottom: 0.3rem;
        }

        .card-box {
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 1rem;
            margin-top: 1rem;
            background-color: #fdfdfd;
        }

        @media (min-width: 768px) {
            .box-search {
                flex-direction: row;
                justify-content: center;
            }

            .box-search input {
                max-width: 400px;
                margin-right: 1rem;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid justify-content-between">
            <img src="assets/img/LOGO.png" alt="Logo">
            <a href="sair.php" class="btn btn-danger">Sair</a>
        </div>
    </nav>

    <div class="box-search">
        <input type="search" class="form-control" placeholder="Pesquisar usuários..." id="pesquisar">
        <button onclick="searchData()" class="btn btn-search">Buscar</button>
    </div>

    <div class="container">
        <h2>Painel de Gerenciamento</h2>
        <p class="text-muted">Administre turmas, cursos e alunos com facilidade.</p>

        <div>
            <span class="section-title">Turmas</span>
            <div class="card-box">
                <p><strong>Ação:</strong> Criar, editar ou excluir turmas disponíveis.</p>
                <a href="gerenciar_turmas.php" class="btn btn-primary btn-sm">Gerenciar Turmas</a>
            </div>
        </div>

        <div>
            <span class="section-title">Cursos</span>
            <div class="card-box">
                <p><strong>Ação:</strong> Cadastrar novos cursos e vincular às turmas.</p>
                <a href="gerenciar_cursos.php" class="btn btn-primary btn-sm">Gerenciar Cursos</a>
            </div>
        </div>

        <div>
            <span class="section-title">Inscrições de Alunos</span>
            <div class="card-box">
                <p><strong>Ação:</strong> Visualizar e administrar alunos inscritos em turmas/cursos.</p>
                <a href="gerenciar_usuarios.php" class="btn btn-primary btn-sm">Gerenciar Inscrições</a>
            </div>
        </div>
    </div>

    <script>
        function searchData() {
            const query = document.getElementById('pesquisar').value;
            window.location = 'sistema.php?search=' + encodeURIComponent(query);
        }
    </script>
</body>
</html>
