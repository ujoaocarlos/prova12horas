<?php
include_once('config.php');
// Exibe lista de turmas
$result = $conexao->query("SELECT * FROM turmas");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Gerenciar Turmas</title>
    <link rel="stylesheet" href="..."> <!-- Utilize os mesmos estilos do sistema -->
</head>
<body>
    <h2>Gerenciamento de Turmas</h2>
    <a href="criar_turma.php" class="btn btn-custom">Criar nova turma</a>
    <table class="table table-bordered mt-4">
        <thead><tr><th>ID</th><th>Nome</th><th>Ações</th></tr></thead>
        <tbody>
        <?php while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['nome']}</td>
                    <td>
                        <a href='editar_turma.php?id={$row['id']}' class='btn btn-editar'>Editar</a>
                        <a href='excluir_turma.php?id={$row['id']}' class='btn btn-excluir'>Excluir</a>
                    </td>
                  </tr>";
        } ?>
        </tbody>
    </table>
</body>
</html>