<?php
if (isset($_POST['submit'])) {
    include_once('config.php');

    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $senha = $_POST['senha'];
    $email = $_POST['email'];
    $ra = $_POST['ra'];
    $sexo = $_POST['genero'];
    $data_nasc = $_POST['data_nascimento'];
    $cidade = $_POST['cidade'];
    $estado = $_POST['estado'];
    $endereco = $_POST['endereco'];

    // Atualiza os dados no banco
    $sqlUpdate = "UPDATE usuarios SET 
        nome='$nome',
        senha='$senha',
        email='$email',
        ra='$ra',
        sexo='$sexo',
        data_nasc='$data_nasc',
        cidade='$cidade',
        estado='$estado',
        endereco='$endereco'
        WHERE id=$id";

    $result = $conexao->query($sqlUpdate);

    if ($result === TRUE) {
        // Redireciona após atualizar
        header('Location: sistema.php');
    } else {
        echo "Erro ao atualizar: " . $conexao->error;
    }
} else {
    echo "Requisição inválida.";
}
?>
