<?php
session_start();
include 'config.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login - Sistema Acadêmico</title>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet"/>
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Montserrat', sans-serif;
      background-color: #E8F0FE;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }

    .login-container {
      background-color: white;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.1);
      width: 100%;
      max-width: 400px;
      text-align: center;
    }

    .login-container > a {
        display: inline-block;
        color: #0074D9;
        font-weight: 600;
        text-decoration: none;
        padding: 8px 16px;
        margin-top: 20px;
        border: 2px solid #0074D9;
        border-radius: 8px;
        transition: background-color 0.3s, color 0.3s;
        cursor: pointer;
      }

      .login-container > a:hover {
        background-color: #0074D9;
        color: white;
      }

    .login-container  img {
        display: block;
        margin: 0 auto 20px auto; /* centraliza horizontalmente e adiciona margem abaixo */
        height: 50px;     
        width: auto;   
      }

    .login-container h1 {
      margin-bottom: 1.5rem;
      font-size: 1.8rem;
      color: #1a1a1a;
    }

    .login-container form {
      text-align: left;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      font-weight: 600;
      margin-bottom: 8px;
      color: #1a1a1a;
    }

    .form-group label.required::after {
      content: " *";
      color: red;
    }

    .login-container input[type="text"],
    .login-container input[type="password"],
    .login-container select {
      width: 100%;
      padding: 12px 16px;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 1rem;
      transition: all 0.3s ease;
      opacity: 0; /* começa invisível para animação */
    }

    .login-container input[type="text"]:focus,
    .login-container input[type="password"]:focus,
    .login-container select:focus {
      border-color: #0074D9;
      outline: none;
      box-shadow: 0 0 5px rgba(0,116,217,0.5);
    }

    .login-container button {
      margin-top: 20px;
      width: 100%;
      padding: 12px;
      font-size: 1rem;
      font-weight: bold;
      background-color: #0074D9;
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s;
      opacity: 0; /* também para animação */
    }

    .login-container button:hover {
      background-color: #005fa3;
    }

    .login-container a {
      display: inline-block;
      margin-top: 20px;
      text-decoration: none;
      color: #0074D9;
      font-weight: 500;
    }

    @media (max-width: 500px) {
      .login-container {
        padding: 30px 20px;
      }
    }
  </style>
</head>
<body>

  <div class="login-container">
    <img src="assets/img/LOGO2.png" alt="Logo">
    <h1>Entrar</h1>
    <form action="testLogin.php" method="POST" id="loginForm">
      <div class="form-group">
        <label for="email" class="required">Email</label>
        <input type="text" id="email" name="email" placeholder="Email" required>
      </div>
      <div class="form-group">
        <label for="senha" class="required">Senha</label>
        <input type="password" id="senha" name="senha" placeholder="Senha" required>
      </div>

      <button type="submit" name="submit">Entrar</button>
    </form>
    <a href="home.php">← Voltar</a>
  </div>

  <script>
    // Animação de foco com leve delay para inputs e select e botão
    const inputs = document.querySelectorAll("#loginForm input, #loginForm select, #loginForm button");
    inputs.forEach((el, i) => {
      setTimeout(() => {
        el.style.transition = 'opacity 0.5s ease';
        el.style.opacity = 1;
      }, 200 + i * 150);
    });

    // Suavidade ao enviar o formulário
    const form = document.getElementById("loginForm");
    form.addEventListener("submit", () => {
      form.style.opacity = 0.7;
    });
  </script>

</body>
</html>
