<?php
session_start();
include_once('config.php');

if((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true)) {
    unset($_SESSION['email']);
    unset($_SESSION['senha']);
    header('Location: login.php');
}
$logado = $_SESSION['email'];

if(!empty($_GET['search'])) {
    $data = $_GET['search'];
    $sql = "SELECT * FROM usuarios WHERE id LIKE '%$data%' OR nome LIKE '%$data%' OR telefone LIKE '%$data%' OR email LIKE '%$data%' ORDER BY id DESC";
} else {
    $sql = "SELECT * FROM usuarios ORDER BY id DESC";
}
$result = $conexao->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8" />
    <title>Sistema Acadêmico - Lista de Usuários</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet" />
    <style>
        /* Reset básico e fonte */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Montserrat', sans-serif;
        }

        body {
            background-color: #f4f7f9;
            line-height: 1.5;
            min-height: 100vh;
            margin: 0;
            padding: 0;
        }

        /* HEADER */
        .header {
            background-color: #0074D9;
            padding: 20px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }

        .header img {
            height: 50px;    
            width: auto;     
            object-fit: contain;
          margin-left: 1.5rem;
        }

        .logout-btn {
            background-color: #dc3545;
            padding: 10px 20px;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 600;
            white-space: nowrap;
            flex-shrink: 0;
            transition: background-color 0.3s ease;
        }

        .logout-btn:hover {
            background-color: #b02a37;
        }

        /* CONTAINER DE BUSCA */
        .search-container {
            margin: 20px auto;
            display: flex;
            justify-content: center;
            gap: 10px;
            flex-wrap: wrap;
            max-width: 600px;
            padding: 0 15px;
        }

        .search-container input {
            flex: 1 1 300px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            min-width: 0;
        }

        .search-container button {
            background-color: #0074D9;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease;
            flex-shrink: 0;
        }

        .search-container button:hover {
            background-color: #009fcd;
        }

        /* CONTAINER PRINCIPAL */
        .container {
            max-width: 1100px;
            margin: 30px auto 50px;
            background-color: #fff;
            padding: 20px 30px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 12px;
        }

        .title {
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .subtitle {
            font-size: 16px;
            color: #666;
            margin-bottom: 20px;
        }

        /* TABELA - responsiva */
        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 800px;
        }

        thead {
            background-color: #0074D9;
            color: white;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            font-size: 15px;
            white-space: nowrap;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        /* BOTÕES DE AÇÃO */
        .action-buttons {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            margin-top: 20px;
            gap: 20px;
            padding: 0 15px;
        }
        
        .btn-voltar,
        .btn-cadastrar {
            background-color: #0074D9;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: 600;
            transition: background-color 0.3s ease;
            border: none;
            cursor: pointer;
            flex-shrink: 0;
            white-space: nowrap;
        }

        .btn-cadastrar{
            font-size: 16px;
            padding: 13px 20px;
        }

        .btn-voltar:hover,
        .btn-cadastrar:hover {
            background-color: #009fcd;
        }

        /* MODAL */
        .modal {
            display: none; /* escondido inicialmente */
            position: fixed;
            z-index: 1000;
            left: 0; top: 0;
            width: 100%; height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.5);
        }

        .modal-content {
            background-color: #fff;
            margin: 8% auto;
            padding: 20px 30px;
            border-radius: 12px;
            max-width: 400px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
            position: relative;
            box-shadow: 0 0 15px rgba(0,0,0,0.3);
        }

        .close-btn {
            color: #aaa;
            position: absolute;
            top: 15px;
            right: 20px;
            font-size: 30px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s ease;
            padding: 5px 10px;
            user-select: none;
        }

        .close-btn:hover {
            color: #000;
        }

        .modal form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .modal label {
            font-weight: 600;
            font-size: 14px;
            color: #333;
        }

        .modal input,
        .modal select {
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 16px;
            font-family: 'Montserrat', sans-serif;
            width: 100%;
            box-sizing: border-box;
        }

        .modal button[type="submit"] {
            background-color: #0074D9;
            color: white;
            border: none;
            border-radius: 6px;
            padding: 14px;
            font-weight: 700;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            width: 100%;
        }

        .modal button[type="submit"]:hover {
            background-color: #009fcd;
        }

        /* RESPONSIVIDADE */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: center;
                gap: 10px;
                text-align: center;
            }

            .logout-btn {
                width: 100%;
                max-width: 250px;
                text-align: center;
            }

            .search-container {
                flex-direction: column;
                align-items: center;
                max-width: 100%;
            }

            .search-container input,
            .search-container button {
                width: 90%;
                max-width: 400px;
            }

            .action-buttons {
                flex-direction: column;
                align-items: stretch;
            }

            .btn-voltar,
            .btn-cadastrar {
                width: 100%;
                text-align: center;
            }

            table {
                display: block;
                overflow-x: auto;
                min-width: 0;
            }

            th, td {
                white-space: nowrap;
            }
        }
    </style>
</head>
<body>

    <div class="header">
        <img src="assets/img/LOGO.png" alt="Logo">
        <a class="logout-btn" href="sair.php">Sair</a>
    </div>

    <div class="search-container">
        <input type="text" id="search" placeholder="Pesquisar usuários..." />
        <button onclick="searchData()">Buscar</button>
    </div>

    <div class="container">
        <div class="title">Painel de Cursos</div>
        <div class="subtitle">Visualize e gerencie os dados dos Cursos.</div>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome</th>
                        <th>Senha</th>
                        <th>Email</th>
                        <th>RA</th>
                        <th>Sexo</th>
                        <th>Data Nasc.</th>
                        <th>Cidade</th>
                        <th>Estado</th>
                        <th>Endereço</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        while($user_data = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>".htmlspecialchars($user_data['id'])."</td>";
                            echo "<td>".htmlspecialchars($user_data['nome'])."</td>";
                            echo "<td>".htmlspecialchars($user_data['senha'])."</td>";
                            echo "<td>".htmlspecialchars($user_data['email'])."</td>";
                            echo "<td>".htmlspecialchars($user_data['ra'])."</td>";
                            echo "<td>".htmlspecialchars($user_data['sexo'])."</td>";
                            echo "<td>".htmlspecialchars($user_data['data_nasc'])."</td>";
                            echo "<td>".htmlspecialchars($user_data['cidade'])."</td>";
                            echo "<td>".htmlspecialchars($user_data['estado'])."</td>";
                            echo "<td>".htmlspecialchars($user_data['endereco'])."</td>";
                            echo "</tr>";
                        }
                    ?>
                </tbody>
            </table>
        </div>

        <div class="action-buttons">
            <a href="sistema.php" class="btn-voltar">Voltar ao Painel</a>
            <button class="btn-cadastrar" id="openModalBtn">Cadastrar Curso</button>
        </div>
    </div>

    <!-- Modal -->
    <div id="cursoModal" class="modal" aria-hidden="true" role="dialog" aria-labelledby="modalTitle" aria-modal="true">
        <div class="modal-content">
            <button class="close-btn" id="closeModalBtn" aria-label="Fechar modal">&times;</button>
            <h2 id="modalTitle">Cadastrar Curso</h2>
            <form action="create_curso.php" method="POST" autocomplete="off">
                <label for="nome_curso">Nome do Curso</label>
                <input type="text" id="nome_curso" name="nome_curso" required placeholder="Nome do Curso" />

                <label for="descricao">Descrição</label>
                <input type="text" id="descricao" name="descricao" required placeholder="Descrição do Curso" />

                <label for="qtd_semestres">Quantidade de Semestres</label>
                <input type="number" id="qtd_semestres" name="qtd_semestres" required min="1" max="12" placeholder="Ex: 6" />

                <button type="submit">Cadastrar</button>
            </form>
        </div>
    </div>

    <script>
        // Função para pesquisa
        function searchData() {
            const searchValue = document.getElementById('search').value.trim();
            if(searchValue.length > 0) {
                window.location = 'listar_usuarios.php?search=' + encodeURIComponent(searchValue);
            } else {
                window.location = 'listar_usuarios.php';
            }
        }

        // Atalho Enter para buscar
        document.getElementById('search').addEventListener('keydown', function(event) {
            if(event.key === 'Enter') {
                event.preventDefault();
                searchData();
            }
        });

        // Modal
        const openModalBtn = document.getElementById('openModalBtn');
        const closeModalBtn = document.getElementById('closeModalBtn');
        const modal = document.getElementById('cursoModal');

        openModalBtn.addEventListener('click', () => {
            modal.style.display = 'block';
            modal.setAttribute('aria-hidden', 'false');
            document.getElementById('nome_curso').focus();
        });

        closeModalBtn.addEventListener('click', () => {
            modal.style.display = 'none';
            modal.setAttribute('aria-hidden', 'true');
        });

        window.addEventListener('click', (event) => {
            if(event.target === modal) {
                modal.style.display = 'none';
                modal.setAttribute('aria-hidden', 'true');
            }
        });

        // Fechar modal com Esc
        window.addEventListener('keydown', (event) => {
            if(event.key === 'Escape' && modal.style.display === 'block') {
                modal.style.display = 'none';
                modal.setAttribute('aria-hidden', 'true');
            }
        });
    </script>

</body>
</html>
