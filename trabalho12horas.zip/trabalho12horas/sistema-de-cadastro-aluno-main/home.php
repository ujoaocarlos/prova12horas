<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Sistema Acadêmico</title>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet"/>
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Montserrat', sans-serif;
      background-color: #E8F0FE;
      color: #1a1a1a;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 3rem;
      background-color: white;
      border-bottom: 1px solid #ccc;
    }

    .navbar img{
      display: block;
      margin-left: 1.5rem;
      height: 50px;     
      width: auto;  
    }

    .hero {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 4rem 6%;
      flex-wrap: wrap;
      flex-grow: 1;
    }

    .hero-text {
      max-width: 800px;
    }

    .hero-text h1 {
      font-size: 4.5rem;
      margin-bottom: 1rem;
      color:  #0074D9;
      font-weight: bold;
    }

    .hero-text p {
      font-size: 1.25rem;
      margin-bottom: 2rem;
      color: #555;
    }

    .hero-text .cta {
      background-color: #0074D9;
      color: white;
      padding: 0.9rem 2rem;
      font-size: 1rem;
      font-weight: bold;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s;
      text-decoration: none;
      display: inline-block;
    }

    .hero-text img{
      width: 98px;
      margin-bottom: 1.75rem;
    }

    .hero-text .cta:hover {
      background-color: #005fa3;
    }

    .hero-img img {
      max-width: 750px;
      width: 100%;
      height: auto;
      margin-bottom: 0 !important;
    }

    footer {
      text-align: center;
      font-size: 0.8rem;
      padding: 2rem 1rem;
      background: #f8f8f8;
      color: #888;
    }

    .actions a {
      background-color: #0074D9;
      color: white;
      padding: 8px 16px;
      border-radius: 6px;
      text-decoration: none;
      font-weight: 600;
      transition: background-color 0.3s ease;
      display: inline-block;
      cursor: pointer;
    }

    .actions a:hover {
      background-color: #005fa3;
    }
    @media (max-width: 768px) {
      .hero {
        flex-direction: column;
        text-align: center;
      }

      .hero-text h1 {
        font-size: 2.2rem;
      }

      .hero-img {
        margin-top: 2rem;
      }
    }
  </style>
</head>
<body>

  <div class="navbar">
    <img src="assets/img/LOGO2.png" alt="Logo">
    <div class="actions">
      <a href="login.php">Entrar</a>
    </div>
  </div>

  <section class="hero">
    <div class="hero-text">
     <img src="assets/img/LOGO2.png" alt="Logo">
      <h1>ORGANIZE SUA ESCOLA COM MAIS FACILIDADE</h1>
      <p>Desenvolvemos um sistema robusto que permite cadastrar alunos de forma ágil e segura, garantindo a integridade dos dados. O gerenciamento de turmas se torna intuitivo, facilitando a organização do ano letivo. E com nosso sistema de relatórios, você acompanha o progresso da sua escola em tempo real, com informações precisas e confiáveis para uma gestão transparente e segura.</p>
      <a href="formulario.php" class="cta">Criar Conta Grátis</a>
    </div>
    <div class="hero-img">
      <img src="assets/img/student.png" alt="Logo">
    </div>
  </section>

  <footer>
    &copy; <?php echo date("Y"); ?> Sistema Acadêmico. Todos os direitos reservados.
  </footer>

</body>
</html>
