<?php
session_start();
include_once('config.php');

if((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true)) {
    unset($_SESSION['email']);
    unset($_SESSION['senha']);
    header('Location: login.php');
}
$logado = $_SESSION['email'];

if(!empty($_GET['search'])) {
    $data = $_GET['search'];
    $sql = "SELECT * FROM usuarios WHERE id LIKE '%$data%' OR nome LIKE '%$data%' OR telefone LIKE '%$data%' OR email LIKE '%$data%' ORDER BY id DESC";
} else {
    $sql = "SELECT * FROM usuarios ORDER BY id DESC";
}
$result = $conexao->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Sistema Acadêmico - Lista de Alunos</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Montserrat', sans-serif;
        }

        body {
            background-color: #f4f7f9;
            margin: 0;
            padding: 0;
        }

        .header {
            background-color: #0074D9;
            padding: 20px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }

        .header h1 {
            font-size: 24px;
        }

        .logout-btn {
            background-color: #dc3545;
            padding: 10px 20px;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 600;
        }

        .search-container {
            margin: 20px auto;
            display: flex;
            justify-content: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .search-container input {
            width: 300px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .search-container button {
            background-color: #0074D9;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-weight: 600;
            cursor: pointer;
        }

        .header img{
             height: 50px;    
            width: auto;     
            object-fit: contain;
            margin-left: 1.5rem;
        }

        .container {
            max-width: 1100px;
            margin: 30px auto;
            background-color: #fff;
            padding: 20px 30px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 12px;
        }

        .title {
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .subtitle {
            font-size: 16px;
            color: #666;
            margin-bottom: 20px;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 800px;
        }

        thead {
            background-color: #0074D9;
            color: white;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            font-size: 15px;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .action-buttons {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            margin-top: 20px;
            gap: 20px;
        }

        .btn-voltar,
        .btn-cadastrar {
            background-color: #0074D9;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }

        .btn-voltar:hover,
        .btn-cadastrar:hover {
            background-color: #009fcd;
        }

        button.btn-cadastrar {
            background-color: #0074D9;
            color: white;
            font-size: 16px;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: 800;
            transition: background-color 0.3s ease;
            border: none;
            cursor: pointer;
        }

         .modal {
        display: none; /* oculto por padrão */
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0,0,0,0.4); /* fundo preto transparente */
    }

    .modal-content {
        background-color: #fefefe;
        margin: 10% auto; /* 10% do topo e centralizado horizontal */
        padding: 20px 30px;
        border-radius: 12px;
        width: 90%;
        max-width: 500px;
        box-shadow: 0 0 10px rgba(0,0,0,0.25);
        position: relative;
    }

    .close-btn {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
        position: absolute;
        right: 20px;
        top: 10px;
    }

    .close-btn:hover,
    .close-btn:focus {
        color: #000;
        text-decoration: none;
    }

    /* Inputs básicos */
    input, select {
        width: 100%;
        padding: 8px 10px;
        margin-top: 4px;
        margin-bottom: 12px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 14px;
    }


@media (max-width: 768px) {
    .search-container {
        flex-direction: column;
        align-items: center;
    }

    .search-container input,
    .search-container button {
        width: 90%;
        max-width: 400px;
    }

    .action-buttons {
        flex-direction: column;
        align-items: stretch;
    }

    .btn-voltar,
    .btn-cadastrar {
        width: 100%;
        text-align: center;
    }

    table {
        display: block;
        overflow-x: auto;
    }

    .header {
        flex-direction: column;
        text-align: center;
        gap: 10px;
    }
}
    </style>
</head>
<body>

    <div class="header">
        <img src="assets/img/LOGO.png" alt="Logo">
        <a class="logout-btn" href="sair.php">Sair</a>
    </div>

    <div class="search-container">
        <input type="text" id="search" placeholder="Pesquisar usuários..." />
        <button onclick="searchData()">Buscar</button>
    </div>

    <div class="container">
        <div class="title">Painel de Alunos</div>
        <div class="subtitle">Cadastre, visualize e gerencie os dados dos alunos.</div>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome</th>
                        <th>Senha</th>
                        <th>Email</th>
                        <th>RA</th>
                        <th>Sexo</th>
                        <th>Data Nasc.</th>
                        <th>Cidade</th>
                        <th>Estado</th>
                        <th>Endereço</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        while($user_data = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>".$user_data['id']."</td>";
                            echo "<td>".$user_data['nome']."</td>";
                            echo "<td>".$user_data['senha']."</td>";
                            echo "<td>".$user_data['email']."</td>";
                            echo "<td>".$user_data['ra']."</td>";
                            echo "<td>".$user_data['sexo']."</td>";
                            echo "<td>".$user_data['data_nasc']."</td>";
                            echo "<td>".$user_data['cidade']."</td>";
                            echo "<td>".$user_data['estado']."</td>";
                            echo "<td>".$user_data['endereco']."</td>";
                            echo "</tr>";
                        }
                    ?>
                </tbody>
            </table>
        </div>

      <div class="action-buttons">
    <a href="sistema.php" class="btn-voltar">Voltar ao Painel</a>
    <!-- Mudou de <a> para <button> para abrir modal -->
    <button class="btn-cadastrar" id="openModalBtn">Cadastrar Aluno</button>
</div>

<!-- Modal -->
<div id="modalCadastro" class="modal">
    <div class="modal-content">
        <span class="close-btn" id="closeModalBtn">&times;</span>
        <h2 style="margin-bottom: 20px; color: #0074D9; font-size: 22px; font-weight: 700;">Cadastro de Aluno</h2>
        <form action="cadastrar_aluno.php" method="POST">

            <label for="nome">Nome:</label>
            <input type="text" name="nome" id="nome" required>

            <label for="senha">Senha:</label>
            <input type="password" name="senha" id="senha" required>

            <label for="email">Email:</label>
            <input type="email" name="email" id="email" required>

            <label for="ra">RA:</label>
            <input type="text" name="ra" id="ra">

            <label for="sexo">Sexo:</label>
            <select name="sexo" id="sexo">
                <option value="">Selecione</option>
                <option value="Masculino">Masculino</option>
                <option value="Feminino">Feminino</option>
            </select>

            <label for="data_nasc">Data de Nascimento:</label>
            <input type="date" name="data_nasc" id="data_nasc">

            <label for="cidade">Cidade:</label>
            <input type="text" name="cidade" id="cidade">

            <label for="estado">Estado:</label>
            <input type="text" name="estado" id="estado">

            <label for="endereco">Endereço:</label>
            <input type="text" name="endereco" id="endereco">

            <button type="submit" style="
                background-color: #0074D9;
                color: white;
                font-weight: 700;
                padding: 10px 20px;
                border: none;
                border-radius: 8px;
                cursor: pointer;
                font-size: 15px;
                margin-top: 10px;
                width: 100%;
            ">Cadastrar</button>
        </form>
    </div>
</div>

    <script>
        function searchData() {
            const search = document.getElementById('search').value;
            window.location = 'sistema.php?search=' + encodeURIComponent(search);
        }

          const modal = document.getElementById('modalCadastro');
            const openBtn = document.getElementById('openModalBtn');
            const closeBtn = document.getElementById('closeModalBtn');

            openBtn.onclick = function() {
                modal.style.display = 'block';
            }

            closeBtn.onclick = function() {
                modal.style.display = 'none';
            }

            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = 'none';
                }
            }
    </script>

</body>
</html>
